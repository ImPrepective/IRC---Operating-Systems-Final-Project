#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define MAX_CLIENTS 10
#define MAX_ROOMS 10
#define BUFFER_SIZE 1024
#define NICKNAME_SIZE 32
#define ROOM_NAME_SIZE 32

typedef struct {
    int socket;
    char nickname[NICKNAME_SIZE];
    char current_room[ROOM_NAME_SIZE];
    bool is_logged_in;
} Client;

typedef struct {
    char name[ROOM_NAME_SIZE];
    char owner[NICKNAME_SIZE];
    bool is_open;
} Room;

Client clients[MAX_CLIENTS];
Room rooms[MAX_ROOMS];
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void set_clients() {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        clients[i].socket = -1;
        clients[i].is_logged_in = false;
    }
}

void set_rooms() {
    for (int i = 0; i < MAX_ROOMS; i++) {
        strcpy(rooms[i].name, "");
        strcpy(rooms[i].owner, "");
        rooms[i].is_open = false;
    }
}

int get_available_client_index() {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i].socket == -1) {
            return i;
        }
    }
    return -1;
}

int get_client_index(int client_socket) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i].socket == client_socket) {
            return i;
        }
    }
    return -1;
}

int get_available_room_index() {
    for (int i = 0; i < MAX_ROOMS; i++) {
        if (strcmp(rooms[i].name, "") == 0) {
            return i;
        }
    }
    return -1;
}

bool is_nickname_taken(const char *nickname) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (strcmp(clients[i].nickname, nickname) == 0 && clients[i].is_logged_in) {
            return true;
        }
    }
    return false;
}

bool does_room_exist(const char *room_name) {
    for (int i = 0; i < MAX_ROOMS; i++) {
        if (strcmp(rooms[i].name, room_name) == 0) {
            return true;
        }
    }
    return false;
}

bool is_client_logged_in(int client_socket) {
    int client_index = get_client_index(client_socket);
    if (client_index != -1) {
        return clients[client_index].is_logged_in;
    }
    return false;
}

bool is_client_room_owner(int client_socket, const char *room_name) {
    int client_index = get_client_index(client_socket);
    if (client_index != -1) {
        int room_index = -1;
        for (int i = 0; i < MAX_ROOMS; i++) {
            if (strcmp(rooms[i].name, room_name) == 0) {
                room_index = i;
                break;
            }
        }
        if (room_index != -1) {
            return strcmp(rooms[room_index].owner, clients[client_index].nickname) == 0;
        }
    }
    return false;
}

void log_in_client(int client_socket, const char *nickname) {
    int client_index = get_available_client_index();
    if (client_index != -1) {
        clients[client_index].socket = client_socket;
        strcpy(clients[client_index].nickname, nickname);
        strcpy(clients[client_index].current_room, "Lobby");
        clients[client_index].is_logged_in = true;

        printf("A user logged in as '%s'.\n", nickname);
    }
    else{
    printf("There are maximum number of users now, please try again later...");
    }
}

void log_out_client(int client_socket) {
    int client_index = get_client_index(client_socket);
    if (client_index != -1) {
        printf("User '%s' logged out.\n", clients[client_index].nickname);
        clients[client_index].socket = -1;
        clients[client_index].is_logged_in = false;
        strcpy(clients[client_index].nickname, "");
        strcpy(clients[client_index].current_room, "");
    }
}

void create_room(const char *room_name, const char *owner) {

    int room_index = get_available_room_index();
    if (room_index != -1) {
        strcpy(rooms[room_index].name, room_name);
        strcpy(rooms[room_index].owner, owner);
        rooms[room_index].is_open = true;

        printf("Room '%s' is created by '%s'.\n", room_name, owner);
    }
}


void close_room(const char *room_name) {
    for (int i = 0; i < MAX_ROOMS; i++) {
        if (strcmp(rooms[i].name, room_name) == 0) {
            printf("Room '%s' is closed by '%s'.\n", room_name,rooms[i].owner);
            strcpy(rooms[i].name, "");
            strcpy(rooms[i].owner, "");
            for(int j=0; j < MAX_ROOMS; j++){
            if(strcmp(clients[j].current_room,room_name)==0){
            strcpy(clients[j].current_room,"Lobby");
            send_message_to_client("Owner has closed the room. You are being redirected to lobby.",clients[j].socket);
            }
            }
            rooms[i].is_open = false;
            break;
        }
    }
}



void join_room(int client_socket, const char *room_name) {
    int client_index = get_client_index(client_socket);
    if (client_index != -1) {
        strcpy(clients[client_index].current_room, room_name);   
    }
}

void leave_room(int client_socket) {
    int client_index = get_client_index(client_socket);
    if (client_index != -1) {
        strcpy(clients[client_index].current_room, "");
    }
}

void get_client_current_room(int client_socket, char *room_name) {
    int client_index = get_client_index(client_socket);
    if (client_index != -1) {
        strcpy(room_name, clients[client_index].current_room);
    }
}

void send_message_to_client(const char *message, int client_socket) {
    write(client_socket, message, strlen(message));
}

void send_message_to_room(const char *message, const char *room_name, int sender_socket) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i].socket != -1 && strcmp(clients[i].current_room, room_name) == 0 && clients[i].socket != sender_socket) {
            send_message_to_client(message, clients[i].socket);
        }
    }
}

void send_room_list_to_client(int client_socket) {
    char room_list[BUFFER_SIZE];
    strcpy(room_list, "Rooms:\n");

    for (int i = 0; i < MAX_ROOMS; i++) {
        if (strcmp(rooms[i].name, "") != 0) {
            char room_info[ROOM_NAME_SIZE + NICKNAME_SIZE + 16];
            sprintf(room_info, "- %s (Owner: %s)\n", rooms[i].name, rooms[i].owner);
            strcat(room_list, room_info);
        }
    }

    send_message_to_client(room_list, client_socket);
}

void send_user_list_to_client(int client_socket, const char *room_name) {
    char user_list[BUFFER_SIZE];
    strcpy(user_list, "Users:\n");

    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i].socket != -1 && strcmp(clients[i].current_room, room_name) == 0) {
            strcat(user_list, "- ");
            strcat(user_list, clients[i].nickname);
            strcat(user_list, "\n");
        }
    }

    send_message_to_client(user_list, client_socket);
}

    int size_of_rooms = sizeof(rooms)/sizeof(rooms[0]);

void client_message_manager(int client_socket, char *message) {
    char command[16];
    char argument[64];
    sscanf(message, "%s %[^\n]", command, argument);

    if (strcmp(command, "login") == 0) {
        if (is_client_logged_in(client_socket)) {
            send_message_to_client("You are already logged in.\n", client_socket);
        } else if (is_nickname_taken(argument)) {
            send_message_to_client("Nickname is already taken. Please choose a different nickname.\n", client_socket);
        } else {
            log_in_client(client_socket, argument);
            send_message_to_client("You are now logged in.\n", client_socket);
        }
    } else if (!is_client_logged_in(client_socket)) {
        send_message_to_client("You need to log in first.\n", client_socket);
    } else if (strcmp(command, "logout") == 0) {
        log_out_client(client_socket);
        send_message_to_client("You are now logged out.\n", client_socket);
    } else if (strcmp(command, "list") == 0) {
        if (strcmp(argument, "rooms") == 0) {
            send_room_list_to_client(client_socket);
        } else if (strcmp(argument, "users") == 0) {
            char room_name[ROOM_NAME_SIZE];
            get_client_current_room(client_socket, room_name);
            if (strcmp(room_name, "") == 0) {
                send_message_to_client("You are not currently in a room.\n", client_socket);
            } else {
                send_user_list_to_client(client_socket, room_name);
            }
        } else {
            send_message_to_client("Invalid command. Usage: list [rooms|users]\n", client_socket);
        }
    } else if (strcmp(command, "enter") == 0) {
        if (does_room_exist(argument)) {
            join_room(client_socket, argument);
            send_message_to_client("You have entered the room.\n", client_socket);
        } else {
            send_message_to_client("Room does not exist.\n", client_socket);
        }
    } else if (strcmp(command, "whereami") == 0) {
        char room_name[ROOM_NAME_SIZE];
        get_client_current_room(client_socket, room_name);
        if (strcmp(room_name, "") == 0) {
            send_message_to_client("You are not currently in a room.\n", client_socket);
        } else {
            char message[BUFFER_SIZE];
            sprintf(message, "You are in the room '%s'.\n", room_name);
            send_message_to_client(message, client_socket);
        }
    } else if (strcmp(command, "open") == 0) {
        if (!does_room_exist(argument)) {
            create_room(argument, clients[get_client_index(client_socket)].nickname);
            join_room(client_socket, argument);
            send_message_to_client("Room created and you have entered the room.\n", client_socket);
        } else {
            send_message_to_client("Room already exists.\n", client_socket);
        }
    } else if (strcmp(command, "close") == 0) {
        if (is_client_room_owner(client_socket, argument)) {
            leave_room(client_socket);
            close_room(argument);
            send_message_to_client("Room closed.\n", client_socket);
        } else {
            send_message_to_client("You are not the owner of the room.\n", client_socket);
        }
    } else if (strcmp(command, "leave") == 0) {
        leave_room(client_socket);
        send_message_to_client("You have left the room.\n", client_socket);
    } else if (strcmp(command, "msg") == 0) {
        char room_name[ROOM_NAME_SIZE];
        get_client_current_room(client_socket, room_name);
        if (strcmp(room_name, "") == 0) {
            send_message_to_client("You are not currently in a room.\n", client_socket);
        } else {
            char full_message[BUFFER_SIZE];
            sprintf(full_message, "[%s]: %s\n", clients[get_client_index(client_socket)].nickname, argument);
            send_message_to_room(full_message, room_name, client_socket);
        }
    } 
    
    else {
        send_message_to_client("Invalid command.\n", client_socket);
    }
    
}

void *client_thread(void *arg) {
    int client_socket = *((int *)arg);
    char buffer[BUFFER_SIZE];

    while (true) {
        int read_size = read(client_socket, buffer, BUFFER_SIZE);
        if (read_size <= 0) {
            pthread_mutex_lock(&mutex);
            log_out_client(client_socket);
            pthread_mutex_unlock(&mutex);
            break;
        } else {
            buffer[read_size] = '\0';
            pthread_mutex_lock(&mutex);
            client_message_manager(client_socket, buffer);
            pthread_mutex_unlock(&mutex);
        }
    }

    close(client_socket);
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {

    set_clients();
    set_rooms();

    int port = 1768;

    int server_socket, client_socket;
    struct sockaddr_in server_address, client_address;
    socklen_t client_address_length;

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        printf("Socket creation failed");
        return 1;
    }

    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(port);

    int bnd = bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address));
    if (bnd < 0) 
    {
        printf("Bind failed");
        return 1;
    }

    int listn = listen(server_socket, MAX_CLIENTS);
    if (listn < 0) 
    {
        printf("Listen failed");
        return 1;
    }

    printf("Server started. Listening on port %d...\n", port);

    while (true) 
    {
        client_address_length = sizeof(client_address);
        client_socket = accept(server_socket, (struct sockaddr *)&client_address, &client_address_length);
        if (client_socket < 0) 
        {
            printf("Accept failed");
            return 1;
        }

        pthread_t thread_id;
        if (pthread_create(&thread_id, NULL, client_thread, &client_socket) != 0) 
        {
            printf("Thread creation failed");
            return 1;
        }
    }

    close(server_socket);

    return 0;
}
